export class PublicationCommentary{

  constructor() {
  }
}
